package project.main;


/**
 * the class represents errors of code lines that don't match the sjavac principles
 */
public class ParsingException extends CompilerException {


}
